# Reproduce from this standalone handoff

Run from the extracted `fm-handoff` directory with the supplied diagnostic
dependencies installed in an isolated Python environment. The original project
uses an `ai/` prefix; the standalone handoff commands below use its own layout.
No API key, server access, or new model generation is required.

```
python audit_reviewed_pilot.py --run raw/v1 --output analysis/v1 --dataset data/eval-only-human-eval-pilot.jsonl.gz
python audit_reviewed_pilot.py --run raw/v2 --output analysis/v2 --dataset data/eval-only-human-eval-pilot.jsonl.gz
python probe_contracts.py --audit-directory analysis/v1 --dataset data/eval-only-human-eval-pilot.jsonl.gz
python probe_contracts.py --audit-directory analysis/v2 --dataset data/eval-only-human-eval-pilot.jsonl.gz
python compare_prompts.py --root . --v1-run raw/v1 --v2-run raw/v2 --v1-evidence analysis/v1 --v2-evidence analysis/v2
```

All 36 source modules and six official test bodies were reviewed for this
handoff. This audit is not a sandbox for future unreviewed generations.
The original model request files and contract text remain unchanged.
See `FM_HANDOFF.md` for immediate FM tasks and the `source/` copies.
