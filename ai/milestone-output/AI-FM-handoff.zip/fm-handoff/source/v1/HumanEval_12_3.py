from typing import List, Optional


def longest(strings: List[str]) -> Optional[str]:
    """ Out of list of strings, return the longest one. Return the first one in case of multiple
    strings of the same length. Return None in case the input list is empty.

    pre:
        len(strings) >= 0
        all(isinstance(s, str) for s in strings)
    post:
        if len(strings) == 0:
            __return__ is None
        else:
            __return__ in strings
            and all(len(__return__) >= len(s) for s in strings)
            and (not any(s == __return__ and strings.index(s) != strings.index(__return__) for s in strings if len(s) == len(__return__)))
            and strings.index(__return__) == min(
                [i for i, s in enumerate(strings) if len(s) == len(__return__)]
            )

    >>> longest([]) is None

    >>> longest(['a', 'b', 'c'])
    'a'
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'
    """
    if not strings:
        return None
    
    max_len = 0
    result = strings[0]
    
    for s in strings:
        if len(s) > max_len:
            max_len = len(s)
            result = s
    
    return result