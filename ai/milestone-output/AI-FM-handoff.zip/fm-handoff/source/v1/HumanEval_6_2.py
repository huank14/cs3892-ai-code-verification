from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]

    pre: paren_string is a string containing one or more groups of balanced parentheses separated by single spaces; each group consists only of '(' and ')' characters and is well-formed (every '(' has a matching ')' and they are properly nested); there are no leading/trailing spaces and no empty groups.
    post: __return__ is a list of integers with the same length as the number of space-separated groups in paren_string; each element is the maximum depth of nesting (>=1) within the corresponding group.
    """
    groups = paren_string.split(' ')
    result: List[int] = []
    for group in groups:
        depth = 0
        max_depth = 0
        for ch in group:
            if ch == '(':
                depth += 1
                if depth > max_depth:
                    max_depth = depth
            elif ch == ')':
                depth -= 1
        result.append(max_depth)
    return result