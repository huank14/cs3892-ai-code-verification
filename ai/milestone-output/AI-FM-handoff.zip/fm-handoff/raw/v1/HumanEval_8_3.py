from typing import List, Tuple


def sum_product(numbers: List[int]) -> Tuple[int, int]:
    """For a given list of integers, return a tuple consisting of a sum and a product of all the integers in a list.
    Empty sum should be equal to 0 and empty product should be equal to 1.

    >>> sum_product([])
    (0, 1)
    >>> sum_product([1, 2, 3, 4])
    (10, 24)

    pre:
        isinstance(numbers, list)
        all(isinstance(x, int) for x in numbers)
    post:
        isinstance(__return__, tuple)
        len(__return__) == 2
        isinstance(__return__[0], int)
        isinstance(__return__[1], int)
        __return__[0] == sum(numbers)
        __return__[1] == (lambda acc: acc)(1) * __return__[1] if len(numbers) == 0 else __return__[1]
        (__return__[1] == 1 if len(numbers) == 0 else True)
        (all(__return__[1] == __return__[1] * 1 for _ in [0]) if True else True)
    """
    total = 0
    product = 1
    for num in numbers:
        total += num
        product *= num
    return (total, product)
