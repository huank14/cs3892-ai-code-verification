from typing import List, Tuple


def sum_product(numbers: List[int]) -> Tuple[int, int]:
    """
    For a given list of integers, return a tuple consisting of a sum and a product of all the integers in a list.
    Empty sum should be equal to 0 and empty product should be equal to 1.

    >>> sum_product([])
    (0, 1)
    >>> sum_product([1, 2, 3, 4])
    (10, 24)

    pre: isinstance(numbers, list) and all(isinstance(n, int) for n in numbers)
    post: (
        isinstance(__return__, tuple)
        and len(__return__) == 2
        and isinstance(__return__[0], int)
        and isinstance(__return__[1], int)
        and __return__[0] == sum(numbers)
        and __return__[1] == _product(numbers)
    )
    """
    total = 0
    prod = 1
    for n in numbers:
        total += n
        prod *= n
    return (total, prod)


def _product(numbers: List[int]) -> int:
    """Helper to compute the product of a list of integers, with empty product equal to 1."""
    result = 1
    for n in numbers:
        result *= n
    return result
