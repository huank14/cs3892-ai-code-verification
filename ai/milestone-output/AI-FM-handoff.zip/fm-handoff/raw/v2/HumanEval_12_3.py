from typing import List, Optional


def longest(strings: List[str]) -> Optional[str]:
    """ Out of list of strings, return the longest one. Return the first one in case of multiple
    strings of the same length. Return None in case the input list is empty.

    >>> longest([])

    >>> longest(['a', 'b', 'c'])
    'a'
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'

    pre: isinstance(strings, list) and all(isinstance(s, str) for s in strings)
    post: (len(strings) == 0) == (__return__ is None)
    post: __return__ is None or __return__ in strings
    post: (len(strings) == 0) or (__return__ is not None and len(__return__) == max(len(s) for s in strings))
    post: (len(strings) == 0) or (__return__ is not None and strings.index(__return__) == min(i for i, s in enumerate(strings) if len(s) == len(__return__)))
    """
    if not strings:
        return None
    return max(strings, key=len)
