from typing import List, Optional


def longest(strings: List[str]) -> Optional[str]:
    """Out of list of strings, return the longest one. Return the first one in case of multiple
    strings of the same length. Return None in case the input list is empty.

    >>> longest([])
    >>> longest(['a', 'b', 'c'])
    'a'
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'

    pre:
        isinstance(strings, list)
        all(isinstance(s, str) for s in strings)
    post:
        (len(strings) == 0) if __return__ is None else True
        (__return__ in strings) if __return__ is not None else True
        (all(len(s) <= len(__return__) for s in strings)) if __return__ is not None else True
        (strings.index(__return__) == next(i for i, s in enumerate(strings) if len(s) == len(__return__))) if __return__ is not None else True
    """
    if not strings:
        return None
    best = strings[0]
    for s in strings[1:]:
        if len(s) > len(best):
            best = s
    return best
